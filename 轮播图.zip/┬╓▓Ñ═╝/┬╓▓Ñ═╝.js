var main=getdom('#main')[0],
    lunbo_img=getdom('#lunbo img'),
    cir_div=getdom('#cir div'),
    left=getdom('#left')[0],
    right=getdom('#right')[0],
    count=0,
    timer=0;
main.onmouseover=function(){
    //清除定时
    if(timer){
        clearInterval(timer);
    }
}
main.onmouseout=function(){
    //自动轮播
    timer=setInterval(function(){
        count++;
        changeimg();
},2000)}
// 圆点控制图片
for(let i=0;i<lunbo_img.length;i++){
    cir_div[i].onclick=function(){
        for(j=0;j<lunbo_img.length;j++){
            if(j==i){
                lunbo_img[i].style.display='block';
                addclass(cir_div[i],'on');
            }else{
                lunbo_img[j].style.display='none';
                removeclass(cir_div[j],'on');
            }
        }
    }
}
// 左右控制图片
left.onclick=function(){//上一张
    count--;
    if(count<0){
        count=lunbo_img.length-1;
    }
    changeimg();
}
right.onclick=function(){//下一张
    count++;
    changeimg();
}
// 获取元素
function getdom(dom){
    return document.querySelectorAll(dom);
} 
//切换图片
function changeimg(){
    if(count>=lunbo_img.length){
         count=0;
    }
    for(let i=0;i<lunbo_img.length;i++){
        lunbo_img[i].style.display='none';
        removeclass(cir_div[i],'on');
    }
    lunbo_img[count].style.display='block';
    addclass(cir_div[count],'on');
} 
//添加元素
function addclass(dom,cn){
    var temp='';
    if(dom.className){
        temp=' ';
    }
    dom.className=dom.className+temp+cn;
}
// 移除元素
function removeclass(dom,cn){
    var str=dom.className;
    var arr=str.split(' '),brr=[];
    arr.forEach(
        function(value,index){
            if(value!=cn){
                brr.push(value);
            }
        })
    dom.className=brr.join(' ');
}
