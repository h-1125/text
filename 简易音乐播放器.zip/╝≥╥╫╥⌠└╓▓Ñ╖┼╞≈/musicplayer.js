var audioDom=getdom('#audioDom')[0],
	play_div=getdom('.play')[0],
	image=getdom('.image_1')[0],
	player=getdom('.player')[0]
	buffbar=getdom('.buffbar')[0],
	time=getdom('.time')[0],
	shangyq=getdom('.shangyq')[0],
	xiayq=getdom('.xiayq')[0],
	sou_route=getdom('.sou_route')[0],
	sou_bar=getdom('.sou_bar')[0],
	sou_mask=getdom('.sou_mask')[0],
	seq_div=getdom('.seq')[0],
	lrc_div=getdom('.lrc')[0];
	var flag=0,tmp=0,count=0,minute=0,cur=0,timer=0,timer1=0,timer2=0,timer5;
	var music=['music/1.mp3','music/2.mp3','music/3.mp3',"music/周杰伦-等你下课.mp3"];
	var lrc=["[00:00.31]海阔天空-Beyond[00:18.51]今天我寒夜里看雪飘过[00:25.16]怀着冷却了的心窝飘远方[00:30.92]风雨里追赶[00:33.74]雾里分不清影踪[00:36.66]天空海阔你与我[00:39.94]可会变(谁没在变)[00:43.61]多少次迎着冷眼与嘲笑[00:49.87]从没有放弃过心中的理想[00:55.71]一刹那恍惚[00:58.85]若有所失的感觉[01:01.64]不知不觉已变淡[01:05.00]心里爱(谁明白我)[01:08.75]原谅我这一生不羁放纵爱自由[01:15.91]也会怕有一天会跌倒 哦NO[01:21.81]背弃了理想谁人都可以[01:28.04]哪会怕有一天只你共我[01:42.76]今天我寒夜里看雪飘过[01:49.18]怀着冷却了的心窝飘远方[01:54.89]风雨里追赶[01:57.96]雾里分不清影踪[02:01.47]天空海阔你与我可会变[02:05.37](谁没在变)[02:07.96]原谅我这一生不羁放纵爱自由[02:15.11]也会怕有一天会跌倒 哦NO[02:21.08]背弃了理想谁人都可以[02:27.57]哪会怕有一天只你共我[02:32.28]哦 yeah[03:08.63]仍然自由自我[03:11.75]永远高唱我歌[03:14.76]走遍千里[03:19.62]原谅我这一生不羁放纵爱自由[03:26.51]也会怕有一天会跌倒[03:31.04]哦NO[03:32.78]背弃了理想谁人都可以[03:39.18]哪会怕有一天只你共我[03:45.57]被弃了理想谁人都可以[03:51.73]哪会怕有一天只你共我[03:56.29]哦yeah[03:57.35]原谅我这一生不羁放纵爱自由[04:02.57]哦yeah[04:04.25]也会怕有一天会跌倒哦[04:10.18]背弃了理想谁人都可以[04:16.64]哪会怕有一天只你共我",
		 "[00:00.31]泡沫-邓紫棋[00:01.47]阳光下的泡沫　是彩色的[00:08.35]就像被骗的我　是幸福的[00:15.45]追究什么对错　你的谎言　基于你还爱我[00:28.79]美丽的泡沫　虽然一刹花火[00:35.76]你所有承诺　虽然都太脆弱[00:42.78]但爱像泡沫　[00:46.41]如果能够看破　有什么难过[00:57.85]早该知道泡沫　一触就破[01:04.84]就像已伤的心　不胜折磨[01:11.83]也不是谁的错　谎言再多　基于你还爱我[01:25.15]美丽的泡沫　虽然一刹花火[01:32.14]你所有承诺　虽然都太脆弱[01:39.25]爱本是泡沫　[01:42.70]如果能够看破　有什么难过[01:53.30]再美的花朵　盛开过就凋落[02:00.39]再亮眼的星　一闪过就坠落[02:07.55]爱本是泡沫　[02:11.19]如果能够看破　有什么难过[02:21.53]为什么难过　有什么难过[02:35.70]为什么难过[02:46.29]全都是泡沫　只一刹的花火[02:53.39]你所有承诺　全部都太脆弱[03:00.55]而你的轮廓　怪我没有看破　[03:07.54]才如此难过[03:14.57]相爱的把握　要如何再搜索[03:21.56]相拥着寂寞　难道就不寂寞[03:28.69]爱本是泡沫　怪我没有看破　[03:35.62]才如此难过[03:43.70]在雨下的泡沫　一触就破[03:50.79]当初炽热的心　早已沉没[03:57.67]说什么你爱我　[04:01.28]如果骗我　我宁愿你沉默",
		 "[00:00.65]我懂了 - 金莎[00:19.07]我在进退的路口[00:23.78]我看不见了天空[00:28.51]我快乐吗 我也好想躲一躲[00:34.38]到你的胸口[00:37.60]我的喜悲你的自由[00:42.13]就像彩虹短暂逗留[00:46.91]你快乐吧[00:49.15]你找到你的出口[00:52.90]你真的自由[00:56.08]我不爱过 就不懂寂寞[01:00.71]我不难过 泪又怎么会流[01:05.25]爱的够重 伤的够痛[01:09.55]证明我爱过[01:14.51]幸福走过 才浮现感动[01:19.14]幸运的我 曾拥你的温柔[01:23.74]你的笑容 还有你问候[01:28.04]都让我心动[01:34.10]你喜欢过 你沉溺过 你残忍过[01:41.07]这一刻我都懂 我真的自由[01:53.78]我的喜悲你的自由[01:58.42]就像彩虹短暂逗留[02:03.02]你快乐吧[02:05.28]你找到你的出口[02:08.99]你真的自由[02:12.30]我不爱过 就不懂寂寞[02:16.86]我不难过 泪又怎么会流[02:21.43]爱的够重 伤的够痛[02:25.70]证明我爱过[02:30.70]幸福走过 才浮现感动[02:35.29]幸运的我 曾拥你的温柔[02:40.00]你的笑容 还有你问候[02:44.14]都让我心动[03:07.69]我不爱过 就不懂寂寞[03:12.33]我不难过 泪又怎么会流[03:17.00]爱的够重 伤的够痛[03:21.15]证明我爱过[03:26.06]幸福走过 才浮现感动[03:30.71]幸运的我 曾拥你的温柔[03:35.34]你的笑容 还有你问候[03:39.62]都让我心动[03:47.99]你喜欢过 你沉溺过 你残忍过[03:54.92]这一刻我都懂 我真的自由","[00:00.71]等你下课 - 周杰伦[00:01.46]词：周杰伦[00:02.26]曲：周杰伦[00:15.23]你住的  巷子里  我租了一间公寓[00:22.33]为了想与你不期而遇[00:28.19]高中三年  我为什么  为什么不好好读书[00:35.50]没考上跟你一样的大学[00:40.40]我找了份工作  离你宿舍很近[00:46.81]当我开始学会做蛋饼  才发现你  不吃早餐[00:54.98]喔  你又擦肩而过[00:59.91]你耳机听什么  能不能告诉我[01:08.20]躺在你学校的操场看星空[01:14.09]教室里的灯还亮着你没走[01:20.92]记得  我写给你的情书[01:27.08]都什么年代了[01:30.40]到现在我还在写着[01:33.92]总有一天总有一年会发现[01:40.07]有人默默的陪在你的身边[01:46.94]也许  我不该在你的世界[01:53.42]当你收到情书[01:56.69]也代表我已经走远[02:25.01]学校旁  的广场  我在这等钟声响[02:32.35]等你下课一起走好吗[02:38.12]弹着琴  唱你爱的歌  暗恋一点都不痛苦（一点都不痛苦）[02:45.35]痛苦的是你  根本没看我[02:50.17]我唱这么走心  却走不进你心里（这么走心  进你心里）[02:56.61]在人来人往  找寻着你  守护着你  不求结局[03:04.68]喔  你又擦肩而过（喔  而过）[03:09.71]我唱告白气球  终于你回了头[03:17.93]躺在你学校的操场看星空[03:23.96]教室里的灯还亮着你没走[03:30.68]记得  我写给你的情书[03:36.80]都什么年代了[03:40.22]到现在我还在写着[03:43.67]总有一天总有一年会发现[03:49.86]有人默默的陪在你的身边[03:56.62]也许  我不该在你的世界[04:03.13]当你收到情书[04:06.39]也代表我已经走远"]
play_div.onclick=function(){
	if(flag!=0){//暂停->播放
		audioDom.pause();
		imagePause();
		if(!hasClassName(play_div,'play')){
		removeClassName(play_div,'stop');
		addClassName(play_div,'play');}flag=0;
	}else{
		removeClassName(play_div,'play');
		addClassName(play_div,'stop');
		start();
		flag=1;
	}
}
// 随机播放
seq_div.onclick=function(){
	if(tmp==0){//顺序->随机
		if(!hasClassName(seq_div,'ran')){
		removeClassName(seq_div,'seq');
		addClassName(seq_div,'ran');tmp=1;}
		}else{//随机->顺序
		removeClassName(seq_div,'ran');
		addClassName(seq_div,'seq');
		tmp=0;
	}
}
//播放完成自动跳转下一曲
audioDom.addEventListener("ended",function(){
	if(seq_div.className=='ran'){//随机
		count = Math.floor(Math.random() * music.length);
		audioDom.src=music[count];
	}else{//顺序
		count++;
		if(count>music.length-1)
			count=0;
		audioDom.src=music[count];
		console.log(count);
	}	
	start();	
},false);
shangyq.onclick=function(){
	before();
}
xiayq.onclick=function(){
	after();
}
//手动播放进度条
buffbar.onmousedown = function(e){
	var x=e.offsetX;
	var lenth=audioDom.duration;
	buffbar.style.width=x+"px";
    audioDom.currentTime=""+parseInt(x*lenth/300)+"";
    audioDom.play();
}
    document.onmouseup = function(){
      document.onmousedown = null; //弹起鼠标不做任何操作
}
// 音量控制
sou_bar.onmousedown=function(e){
	changeVolume(e);
	
	document.onmouseup=function(){
		document.onmousedown = null;
	}
}
function start(){
	qingkonglrc();
	audioDom.play();
	rotate();
	jindutiao();
	addtime();
	showWords();
}
function stop(){
	pauseall();
	imagePause();
	lrc_div.innerHTML='';
	clearInterval(timer5);
}
// 图片转动
function rotate(){
	imagePause();
	var deg=0,lag=1;
    timer=setInterval(function(){
        image.style.transform="rotate("+deg+"deg)";
        deg+=2;
        if(deg>360){
           deg=0;
        }
    },30);
}
// 图片停止转动
function imagePause(){
	clearInterval(timer);
        lag=0;
}
// 进度条
function jindutiao(){
    timer1=setInterval(function(){
    	let num  = parseFloat(cur/audioDom.duration);
        cur=audioDom.currentTime;//获取当前的播放时间
        buffbar.style.width=(num*400)+"px";
    },50)
}
//播放时间
function addtime(){
    timer2=setInterval(function(){
        cur=parseInt(audioDom.currentTime);//秒数
        var temp=cur;
        minute=parseInt(temp/60);
        if(cur%60<10){
            time.innerHTML=""+minute+":0"+cur%60+"";
        }else{
            time.innerHTML=""+minute+":"+cur%60+"";
        }
    },1000);
} 
//上一曲
function before(){
    stop();
    count--;
    if(count==-1){
        count=music.length-1;
    }
    audioDom.src=music[count];
    start();
}
//下一曲
function after(){
	stop();
    count++;
   	if(count>music.length-1){
       count=0;
   }
   audioDom.src=music[count];
   start();
}
//音乐停止
function pauseall(){
    for (let i=0;i<music.length;i++) {
        if(i==count){
        	audioDom.src=music[count];
            audioDom.pause();
        }
    }
}
// 音量控制
function changeVolume(e){
	var x=e.offsetX+20;
	audioDom.volume=parseFloat(x/200)*1;
	sou_bar.style.width=""+x+"px";//改变按钮的位置
}
// 歌词显示
function showWords(){
	var wordsArray=[];
	var arrays=lrc[count].split("[");
	for (var i=0;i < arrays.length ;i++ ){
		var arr = arrays[i].split("]");
		var time1 = arr[0].split(".");
		var timer3 = time1[0].split(":");
		var ms = timer3[0]*60 + timer3[1]*1;//将时间转换为秒
		var text = arr[1];//歌词内容
		var obj={
			time1:ms,
			con:text
		};
		wordsArray.push(obj);
	}
    timer5 = setInterval(function(){
    	for(var i in wordsArray){
    		if(audioDom.currentTime>wordsArray[i].time1){//播放时候的秒数大于数组中的秒数的时候，播放歌词
    			lrc_div.innerHTML=wordsArray[i].con;
    		}
    	}
    },1000);
}
// 清空歌词
function qingkonglrc(){
	lrc_div.innerHTML='';
	clearInterval(timer5);
}
function getdom(dom){
	return document.querySelectorAll(dom);
}
// 添加元素
function addClassName(dom,cn){
	var temp='';
	if(dom.className){
		temp=' ';
	}
	dom.className=dom.className+temp+cn;
}
// 移除元素
function removeClassName(dom,cn){
	var str=dom.className;
	var arr=str.split(' '),brr=[];
	arr.forEach(
		function(value,index){
			if(value!=cn){
				brr.push(value);//尾部追加
			}
		})
	dom.className=brr.join(' ');
}
//判断
function hasClassName(dom,cn){//判断有没有cn这个值
	var str=dom.className;
	var arr=str.split(' ')//用空格分割成数组
	var brr=[],flag=false;
	arr.forEach(//.forEach不能返回ture,false
		function(value,index){
			if(value==cn){
			 flag=true; 
			}
			
		})
	return flag;
}